clear;
clear all;
%% importation des signaux
load parole_bruitee(1).mat;
load decticelle(1).mat ;
%% affichage des signaux de la voix bruitée et des decticelles
figure(1),
plot(d);

figure(10),
plot(x);

%% écoute de la voix et du decticelle
Fe = 8192;
%soundsc(d);
%pause
%soundsc(x);

soustraction_bruit

%% parametre pour l'algo RLS
P=3;
lambda=0.95;
delta=0.001;
% algo_RLS(x,d,P,lambda,delta)