function [e,W] = algo_RLS(x,d,P,lambda,delta)

    n=length(x);
    e=zeros(n,1);
    y=zeros(n,1);
    X=zeros(P,1);
    
    %maintenant on s'occupe de l'allocation mémoire et de l'initialisation
    
    W=zeros(P,n);
    K=(1/delta)*eye(P);
    
    
    for i=1:n
        X=[x(i);X(1:P-1)];
        K=(1/lambda)*(K-((K*conj(X)*X.'*K)/(lambda+X.'*K*conj(X))));
        
        if i==1
            y(i)=d(i);
            W(:,i)=K*conj(X)*y(i);
        else
            y(i)=d(i)-X.'*W(:,i-1);
            W(:,i)=W(:,i-1)+K*conj(X)*y(i);
        end
        
        e(i)=d(i)-W(:,i).'*X;
    end
    
end

